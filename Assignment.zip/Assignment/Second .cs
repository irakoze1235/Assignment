const items =[
    {name:'Bake',price: 100},
    {name : 'TV' ,price: 200},
    {name : 'Album' ,price: 10},
    {name : 'Book' ,price: 5},
    {name : 'Phone' ,price: 500},
    {name : 'Computer' ,price: 1000},],

    //filter the product that will be bought
    const filtererdItem = items.filter((item)=>{
        return item.price<= 10;
    })


    //filter the product that will be expensive



]