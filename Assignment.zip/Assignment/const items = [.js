const items = [
  { name: 'Bike', price: 100 },
  { name: 'TV', price: 200 },
  { name: 'Album', price: 10 },
  { name: 'Book', price: 5 },
  { name: 'Phone', price: 500 },
  { name: 'Computer', price: 1000 }
  
]

// array.filter
const filteredItems = items.filter((item) => {
  return item.price <= 10;
})
console.dir('filter' + filteredItems);


// array.find
const foundItem = items.find((item) => {
  return item.name === 'Computer';
})
console.log(foundItem);


// price of all product
const productItem= item.productItem(item) => {
    return item.price= item * item;
    price ++;


})







console.dir("----------------------------");